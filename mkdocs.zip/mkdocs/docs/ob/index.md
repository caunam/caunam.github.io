# Cấu trúc thị trường x Order Block

> Khóa học kết hợp sử dụng Cấu trúc thị trường và Order Block. Khóa học này có thể sẽ khiến bạn bị rối, phức tạp hơn khóa học CTTT x Key Level nguyên gốc, có thể sẽ không phù hợp với tất cả mọi người.

> - Cấu trúc thị trường x Key Level (Khóa học gốc thuần sử dụng Keylevel)
> - Cấu trúc thị trường x Order Block (Khóa học kết hợp sử dụng Order Block, có thể không phù hợp với tất cả mọi người)
