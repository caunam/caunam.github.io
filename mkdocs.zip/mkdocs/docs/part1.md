# Cấu trúc thị trường x Keylevel

1. Sử dụng Keylevel làm nền tảng
2. Sử dụng đa khung thời gian (Time frame)