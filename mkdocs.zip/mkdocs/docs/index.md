# **Chào mừng đến với bộ tài liệu của Cậu Năm**

<span style="color:red">Muốn giàu có khi còn nghèo? Ngày đi làm kiếm tiền tích vốn mua [DCA Bitcoin](/08/84/), [ETH](15/153/). Ban đêm bỏ ra 2, 3 tiếng mỗi ngày xem đi xem lại video 1000 lần trong 3 năm và thực hành trên demo sẽ có tương lai tươi sáng để bắt đầu với vốn nhỏ. *(16/04/2024)*</span>

> **Lời đầu tiên xin chân thành các tác giả của video, họ là thầy cũng là tiền bối chia sẻ những bộ tài liệu miễn phí rất hữu ích, lý do cậu sợ nó sẽ biến mất đi nên đã lưu trữ và định hướng cho các cháu cậu học tập và có tiền đề chuẩn ngay từ đầu**

## **Một số kinh nghiệm đúc kết của cậu**

1. Trước tiên các cháu cần hiểu bản chất của giá (Mua và Bán), hiểu bản chất của Nến Nhật
2. Luôn quản lý vốn và rủi ro trước, lợi nhuận sau, tham khảo các video [**kinh nghiệm tiền bối**](https://drive.google.com/drive/folders/1BG-_uy-B-_hn4-P3QgrpUXajCEfs-i1_) cậu sưu tầm
3. Một phương pháp giao dịch thật tốt, tốt ở đây là phù hợp bản thân, có điểm vào, lời lỗ, tỷ lệ thắng theo dài hạn, thống kê trong dài hạn.
4. Tâm lý giao dịch vững vàng, kiên định. Nếu phương pháp tốt, thì cứ để thị trường làm việc. Phương pháp của cậu là Price Action **Key Level** mà cậu lưu trữ trên đây.
5. Đầu tư quỹ ETF (E1VFVN30, FUEVN100), DCA Crypto (Bitcoin, ETH, BNB) và [vàng](/08/85/) theo cách DCA vùng.

> _**Chúc các cháu may mắn và kiên định trên con đường đã chọn.**_

Đây là một chương trình test để khẳng định lợi thế của một Phương Pháp tốt và quản lý vốn R/R tốt: [**Phân Tích**](/phan-tich.html) và [**Quản Lý Vốn**](/quan-ly-von.html)

* Hãy học một nghề mà càng làm theo năm tháng tay nghề càng cao và kiếm càng nhiều tiền, [Làm Công Việc 10 Năm Sau Không Hối Hận](https://drive.google.com/file/d/1GGXNntEC_lgJN0rBJEVOXxkRvxtBz1Lr/view)