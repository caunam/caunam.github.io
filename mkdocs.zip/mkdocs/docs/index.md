# **Chào mừng đến với bộ tài liệu của Cậu Năm**

<span style="color:red">Một tương lai tươi sáng luôn bắt đầu từ những khó khăn. Ngày đi làm kiếm tiền tích vốn mua [DCA Bitcoin](/08/84/), [ETH](15/153/). Ban đêm bỏ ra 2, 3 tiếng mỗi ngày xem đi xem lại video 1000 lần trong 3 năm và thực hành backtest trên demo đến thuần thục một phương pháp, sau đó bắt đầu với vốn nhỏ (100$). *(16/04/2024)*</span>

> **Lời đầu tiên xin chân thành cảm ơn các tác giả của video, họ là thầy cũng là tiền bối chia sẻ những bộ tài liệu miễn phí rất hữu ích cho chúng ta, miễn phí không có nghĩa là kém chất lượng**

## **Một số kinh nghiệm đúc kết**

1. Trước tiên cần hiểu bản chất của giá (Mua và Bán), hiểu bản chất của Nến Nhật
2. Luôn quản lý vốn và rủi ro trước, lợi nhuận sau, tham khảo các video [**kinh nghiệm tiền bối**](https://drive.google.com/drive/folders/1BG-_uy-B-_hn4-P3QgrpUXajCEfs-i1_) sưu tầm
3. Một phương pháp giao dịch phù hợp bản thân, mang lại lợi nhuận trong dài hạn, cậu sử dụng Price Action **Key Level** chia sẻ ở đây.
4. Tâm lý giao dịch vững vàng, kiên định.
5. Đầu tư quỹ ETF (E1VFVN30, FUEVN100), DCA Crypto theo từng tuần hoặc chia vốn 20, 40, 30, 10 phần trăm khi thị trường bắt đầu downtrend (chỉ áp dụng Bitcoin, ETH) và [vàng](/08/85/) theo cách DCA vùng.

> _**Gút lúc.**_

Đây là một chương trình test để khẳng định lợi thế của một Phương Pháp tốt và quản lý vốn R/R tốt: [**Phân Tích**](/phan-tich.html) và [**Quản Lý Vốn**](/quan-ly-von.html)

* Hãy học một nghề mà càng làm theo năm tháng tay nghề càng cao và kiếm càng nhiều tiền, [Làm Công Việc 10 Năm Sau Không Hối Hận](https://drive.google.com/file/d/1GGXNntEC_lgJN0rBJEVOXxkRvxtBz1Lr/view)